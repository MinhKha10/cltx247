<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Models/connect.php');
$username = check_string($_POST['username']);
$password = check_string($_POST['password']);
$check_user = $soicoder->num_rows("SELECT * FROM `users` WHERE `username` = '$username'");
if (empty($username) || empty($password)) {
    alert('Vui Lòng Nhập Đầy Đủ Thông Tin', '/'.config_admin.'/login', 1500);
    die;
} else if($check_user == 0) {
    alert('Tài Khoản Không Tồn Tại', '/'.config_admin.'/login', 1500);
    die;
} else {
    $data_user = $soicoder->fetch_assoc("SELECT * FROM `users` WHERE `username` = '$username'", 1);
    if(encrypt($password, LICENSE, ENCRYT) === $data_user['password']) {
        $_SESSION['password'] = $password;
        $_SESSION['username'] = $username;
        $access_token = createToken();
        $soicoder->update("users", array(
            'token' => $access_token,
            'time' => date('H:i:s d/m/Y')
        ), "`username` = '".$username."' ");
        setcookie("username", $username, time() + 600000, "/"); // set cookie username
        setcookie("token", $access_token, time() + 600000, "/"); // set cookie token
        alert('Đăng Nhập Thành Công', '/'.config_admin.'/home', 1000);
        die;
    } else if(encrypt($password, LICENSE, ENCRYT) === $data_user['password_new']) {
        $_SESSION['password'] = $password;
        $_SESSION['username'] = $username;
        $access_token = createToken();
        $soicoder->update("users", array(
            'token' => $access_token,
            'time' => date('H:i:s d/m/Y')
        ), "`username` = '".$username."' ");
        setcookie("username", $username, time() + 600000, "/"); // set cookie username
        setcookie("token", $access_token, time() + 600000, "/"); // set cookie token
        alert('Đăng Nhập Thành Công', '/'.config_admin.'/home', 1000);
        die;
    } else {
        alert('Mật Khẩu Không Chính Xác', '/'.config_admin.'/login', 1500);
        die;
    }
}
