<?php session_start(); ?>
<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Models/connect.php');
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Models/head_request_admin.php');
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Controllers/zalopay/zalopay.php');
$phone = check_string($_GET['phone']);


if (strlen($phone) !== 10) {
    echo "Số điện thoại không đúng định dạng";
    die;
}
$zalopay = new Zalopay($soicoder);
$loadDATA =  $soicoder->fetch_assoc("SELECT * FROM `zalopays` WHERE `phone` = '" . $phone . "' LIMIT 1 ", 1);



// $orderCode = '230311000379478';
// $msg = 'Test resend';
// $amount = 5000;
header("Content-type:text/json");
$get = $zalopay->LoadData($loadDATA)->History_noti(20);
print_r($get);
die;



// get maccesstoken
// $get = $zalopay->LoadData($loadDATA)->info_by_trans_id('230305000468064');
// print_r($get);
// die;

// echo $maccesstoken;



// code bank config
// $file_config_code = json_decode(file_get_contents('code_bank.json'), true);
// print_r($file_config_code); die;
// foreach ($file_config_code as $data) {
//     $soicoder->insert('code_bank' , array (
//         'bankcode' => $data['bankcode'],
//         'bcbankcode' => $data['bcbankcode'],
//         'name' => $data['name'],
//         'fullname' => $data['fullname']
//     ));
// }




// header("Content-type:text/json");

// $config_bank = array(
//     "bankcode" => "MB",
//     "bcbankcode" => "ZPMB",
//     "name" => "MBBank",
//     "fullname" => "Ngân hàng TMCP Quân Đội"
// );
// $description = "Test 2";
// $amount = 20000;
// $stk = '';
// $get = $zalopay->LoadData($loadDATA)->SendMoney_Bank($stk, $amount, $description, $config_bank);
// echo json_encode($get);
// die;












// $info = $zalopay->LoadData($loadDATA)->get_info('0792623572');
// print_r($info);
// die;


// $send = $zalopay->LoadData($loadDATA)->ResendMoney('2306130000206679', "Hi", 39000);
// print_r($send);



