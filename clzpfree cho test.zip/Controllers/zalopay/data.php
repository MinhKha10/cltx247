<?php

Array (
    [trans_id] => 230209001333088 
    [trans_type] => 4 
    [product_code] => TF020 
    [app_id] => 450 
    [description] => Chuyển tiền tới Trinh Quang Truong 
    [trans_time] => 2023-02-09T15:19:29Z 
    [trans_amount] => 1000 
    [sign] => 1 
    [subtotal_amount] => 1000 
    [charge_amount] => 1000 
    [fee_amount] => 0 
    [discount_amount] => 0 
    [pmc] => Ví ZaloPay 
    [status_info] => Array ( 
        [status] => 1 
        [title] => Thành công 
        [message] => 
        [code] => 1
    ) 
    [title] => Nhận tiền 
    [icon] => https://simg.zalopay.com.vn/zst/zpi-spa/cashier/icon/24555-157.png 
    [template_info] => Array ( 
        [template_id] => 2 
        [progress_view] => 
        [custom_fields] => Array ( 
            [0] => Array ( 
                [name] => Mã đơn hàng 
                [value] => 230209000148380 
            ) 
            [1] => Array ( 
                [name] => Người gửi 
                [value] => Ho Van Huy Hoang Tu Mua 
            ) 
            [2] => Array ( 
                [name] => Số điện thoại 
                [value] => ****3572 
            ) 
        ) 
        [custom_views] => 
        [custom_buttons] => Array ( 
            [0] => Array ( 
                [label] => Chuyển lại 
                [link] => /transfer?app_trans_id=230209000148380 
                [priority] => 1 
            ) 
            [1] => Array ( 
                [label] => Xem thiệp 
                [link] => /transfer/greeting/preview/230209000148380 
                [priority] => 2 
            ) 
        ) 
    ) 
    [mode] => 1 
    [trans_note] => 
    [system_type] => 1 
    [app_trans_id] => 230209000148380 
    [ref_trans_id] => 0 
    [balance_snapshot] => 5153 
    [refund_ids] => Array ( ) 
)