<?php session_start(); ?>
<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Models/connect.php');
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Models/head_request_admin.php');
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Controllers/zalopay/zalopay.php');
$phone = check_string($_POST['phone']);
$otp = check_string($_POST['otp']);
$password = check_string($_POST['password']);
if (strlen($phone) == 10) {
    $zalopay = new Zalopay($soicoder);
    $select = $soicoder->num_rows("SELECT * FROM `zalopays` WHERE `phone` = '" . $phone . "' LIMIT 1 ");
    if ($select >= 1) {
        $loadDATA =  $soicoder->fetch_assoc("SELECT * FROM `zalopays` WHERE `phone` = '" . $phone . "' LIMIT 1 ", 1);
        $xacminh = $zalopay->LoadData($loadDATA)->xac_thuc_otp($otp);
        // print_r($xacminh);
        // echo "[xác thực otp]";
        if (isset($xacminh['data']['phone_verified_token'])) {
            $phone_verified_token = $xacminh['data']['phone_verified_token'];
            $login = $zalopay->ZaloLogin($password, $phone_verified_token);
            // print_r($login);
            // die;
            if(!isset($login['error'])){

                $soicoder->update("zalopays", array(
                    'reward'        => $phone,
                    'password'      => $password,
                    'access_token'  => $login['data']['access_token'],
                    'session_id'    => $login['data']['session_id'],
                    'zalo_id'       => $login['data']['zalo_id'],
                    'user_id'       => $login['data']['user_id'],
                    'profile_level' => $login['data']['profile_level'],
                    'status'        => 'success',
                    'min'           => "6000",
                    'max'           => "1000000",
                    'limit_day'     => "200",
                    'limit_month'   => "1000",
                    'errorDesc'     => 'Thành Công',
                    'time_login'    => time(),
                    'pay'           => 'off'
                ), "`phone` = '$phone' ");
                // update số dư
                $loadDATA =  $soicoder->fetch_assoc("SELECT * FROM `zalopays` WHERE `phone` = '" . $phone . "' LIMIT 1 ", 1);
                $get_balance = json_decode($zalopay->LoadData($loadDATA)->getBalance(), true);
                // get maccesstoken
                $get = $zalopay->LoadData($loadDATA)->getlistmerchantuserinfo();
                $maccesstoken = $get['listmerchantuserinfo'][0]['maccesstoken'];
                $mappuser = $get['listmerchantuserinfo'][0]['muid'];
                $soicoder->update("zalopays", array(
                    'balance' => $get_balance['data']['balance'],
                    'maccesstoken' => $maccesstoken,
                    'mappuser' => $mappuser
                ), "`phone` = '$phone' ");
                // die;
                echo "<script language='javascript'>alert('Login Thành Công');window.location='/".config_admin."/zalopay';</script>";
                die;
            } else {
                echo "<script language='javascript'>alert('" . $login['error']['details']['localized_message']['message'] . "');window.location='/".config_admin."/zalopay';</script>";
                die;
            }
        } else {
            $soicoder->update("zalopays", array('status' => 'error', 'errorDesc' => "Otp Không Hợp Lệ"), "`phone` = '$phone' ");
            echo "<script language='javascript'>alert('Otp Không Hợp Lệ');window.location='/".config_admin."/zalopay';</script>";
            die;
        }
    } else {
        echo "<script language='javascript'>alert('Vui Lòng Gửi Otp Trước');window.location='/".config_admin."/zalopay';</script>";
        die;
    }
} else {
    echo "<script language='javascript'>alert('Vui Lòng Nhập Số Điện Thoại');window.location='/".config_admin."/zalopay';</script>";
}
