<?php session_start(); ?>
<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) . '/Models/connect.php');

$render = [];
$list = $soicoder->fetch_assoc("SELECT * FROM `history` WHERE `result` = 'win' ORDER BY id desc LIMIT 10", 0);
$list_game = array(
    'CL' => "Chẵn Lẻ",
    'CL2' => "Chẵn Lẻ 2",
    'TX' => "Tài Xỉu",
    'TX2' => "Tài Xỉu 2",
    '1P3' => "1 Phần 3",
    'G3' => "Gấp 3",
    'T3S' => "Tổng 3 Số",
    'H2S' => "H3"
);
$dem = 0;
foreach ($list as $data) {
    $phone = $data['phone'];
    $value = array(
        "time" => date('H:i:s d/m/Y', $data['time']),
        "phone" => $phone,
        "amount_play" => format_cash($data['trans_amount']),
        "result_number" => format_cash($data['bonus']),
        "game" => $list_game[$data['game']],
        "comment" => $data['description']
    );
    array_push($render, $value);
}

echo json_encode($render, JSON_UNESCAPED_UNICODE);