<?php session_start(); ?>
<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Models/connect.php');
$trans_id = check_string($_POST['trans_id']);

$check = $soicoder->num_rows("SELECT * FROM `history` WHERE `trans_id` = '".$trans_id."' LIMIT 1 ");

if ($check == 0) {
    $return = array(
        'status' => 'error',
        'msg' => "Không Tồn Tại Mã Giao Dịch Này"
    );
    die(json_encode($return));
} else {
    $data = $soicoder->fetch_assoc("SELECT * FROM `history` WHERE `trans_id` = '".$trans_id."' LIMIT 1 ", 1);
    if ($data['result'] == 'win') {
        $return = array(
            'status' => 'success',
            'msg' => $data['status_text'],
            'data' => array(
                'account' => $data['account'],
                'phone' => $data['phone'],
                'phone_result' => $data['phone_result'],
                'trans_id' => $data['trans_id'],
                'trans_amount' => format_cash($data['trans_amount']),
                'game' => $data['game'],
                'description' => $data['description'],
                'bonus' => format_cash($data['bonus']),
                'status_text' => $data['status_text'],
                'msg_bonus' => $data['msg_bonus'],
                'result' => 'Thắng',
                'time' => date('H:i:s d/m/Y', $data['time'])
            )
        );
        die(json_encode($return));
    } else if ($data['status'] == 'wait' || $data['status'] == 'wait_tt') {
        $return = array(
            'status' => 'success',
            'msg' => "WIN | Lỗi Zalopay, Có Thể Admin Thanh Toán Tay Hoặc Tự Động Vào Ngày Mai"
        );
        die(json_encode($return));
    } else if ($data['status'] == 'late') {
        $return = array(
            'status' => 'error',
            'msg' => "Số Đã Tắt, Không Được Trả Thưởng"
        );
        die(json_encode($return));
    } else if ($data['status'] == 'wrong') {
        $return = array(
            'status' => 'error',
            'msg' => "Thua Do Sai Min/Max, Không Được Hoàn Tiền. Vui Lòng Đọc Kĩ Thông Báo"
        );
        die(json_encode($return));
    } else if ($data['status'] == 'wrong_content') {
        $return = array(
            'status' => 'error',
            'msg' => "Thua Do Sai Nội Dung, Không Được Hoàn Tiền. Vui Lòng Đọc Kĩ Thông Báo"
        );
        die(json_encode($return));
    } else {
        $return = array(
            'status' => 'error',
            'msg' => "Thua, Chúc Bạn May Mắn Lần Sau"
        );
        die(json_encode($return));
    }
}


