<?php session_start(); ?>
<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Models/connect.php');
require_once(realpath($_SERVER["DOCUMENT_ROOT"]).'/Models/head_request_admin.php');
$type = check_string($_POST['type']);
$content = check_string($_POST['content']);
$result = check_string($_POST['result']);
$ratio = check_string($_POST['ratio']);
$description = check_string($_POST['description']);
$soicoder->update("game", array(
    'content' => $content,
    'result' => $result,
    'ratio' => $ratio,
    'description' => $description
), "`game_code` = '$type' ");
$return = array(
    'status' => 'success',
    'message' => "Chỉnh Sửa Game Thành Công"
);
die(json_encode($return));