<footer class="footer">
    <div class="container">
        <div class="row align-items-center flex-row-reverse">
            <div class="col-md-12 col-sm-12 mt-3 mt-lg-0 text-center">
                <b></b> © 2026
                <script>
                    document.write(new Date().getFullYear())
                </script> -
                <script>
                    document.write(new Date().getFullYear() + 2)
                </script>
            </div>
        </div>
    </div>
</footer>
<a href="#top" id="back-to-top" style="display: inline;"><i class="fa fa-angle-up"></i></a>


<script src="../../templates/js/vendors/popper.min.js"></script>
<script src="../../templates/js/vendors/bootstrap.min.js"></script>
<script src="../../templates/js/vendors/jquery.sparkline.min.js"></script>
<script src="../../templates/js/sticky.js"></script>
<script src="../../templates/js/clipboard.js"></script>
<script src="../../templates/js/jquery.mousewheel.min.js"></script>
<script src="../../templates/plugins/notify/js/rainbow.js"></script>
<script src="../../templates/plugins/notify/js/jquery.growl.js"></script>
<script src="../../templates/js/jquery.richtext.js"></script>
<script src="../../templates/plugins/select2/select2.full.min.js"></script>
<script src="../../templates/plugins/datatable/jquery.dataTables.min.js"></script>
<script src="../../templates/plugins/datatable/dataTables.bootstrap4.min.js"></script>
<script src="../../templates/plugins/pusher/pusher.min.js"></script>
<script src="../../templates/js/app.js"></script>
</body>

</html>